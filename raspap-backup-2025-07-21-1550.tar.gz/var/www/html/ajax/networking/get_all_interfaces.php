<?php
require_once '../../includes/autoload.php';
require_once '../../includes/CSRF.php';
require_once '../../includes/session.php';
require_once '../../includes/config.php';
require_once '../../includes/authenticate.php';

exec("ls /sys/class/net | grep -v lo", $interfaces);
echo json_encode($interfaces);
