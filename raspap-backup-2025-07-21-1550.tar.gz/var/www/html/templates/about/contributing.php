<!-- about contributing tab -->
<div class="tab-pane fade" id="aboutcontrib">
  <div class="row">
    <div class="col-lg-12 mt-3">
      <?php echo $contributingHtml; ?>
    </div>
  </div><!-- /.row -->
</div><!-- /.tab-pane | contributing tab -->

